# R2 Score 

ranges between 0 and 1

0.90 (good)
0.40 (bad)

# dependent vs independent

y = f(x)

dependent = f(independent)

AbsorptionMax = f(smiles)


# TODO:

- Reorganization of Notebooks
- Addining apropriate comments 